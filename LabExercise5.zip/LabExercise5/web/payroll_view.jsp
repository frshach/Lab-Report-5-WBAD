<%-- 
    Document   : payroll_view
    Created on : 29 Apr 2026, 3:17:09 pm
    Author     : ADMIN
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<!DOCTYPE html>
<html>
<head>
    <title>Employee Payroll System</title>
</head>
<body>

<h2>Employee Payroll Display System</h2>

<table border="1" cellpadding="8">
    <thead>
        <tr style="background-color: blueviolet;">
            <th>No</th>
            <th>Emp ID</th>
            <th>Name</th>
            <th>Department</th>
            <th>Salary (RM)</th>
            <th>Status</th>
        </tr>
    </thead>

    <tbody>
        <c:forEach items="${employeeList}" var="emp" varStatus="status">
            <tr>
                <td>${status.count}</td>
                <td>${emp.empId}</td>
                <td>${emp.name}</td>
                <td>${emp.department}</td>
                <td>${emp.basicSalary}</td>

                <td>
                    <c:choose>
                        <c:when test="${emp.basicSalary >= 3000}">
                            Senior
                        </c:when>
                        <c:otherwise>
                            Junior
                        </c:otherwise>
                    </c:choose>
                </td>
            </tr>
        </c:forEach>
    </tbody>
</table>

</body>
</html>